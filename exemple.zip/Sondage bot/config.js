module.exports = {
    token: "OTkwNjQ4MjQwNjc4NTM1MjA4.GYcncH.9zeMfgPw2urncA1cZWhZyM-48rCwmlZzvz9SeI", // Token du bot
    clientId: "990648240678535208", // ID du bot
    guildId: "988058168124899398", // ID du serveur pour les slash commands
    slashCommandsByGuild: true, // Deployer les commandes seulement sur le serveur du dessus (true) ou sur tous les serveurs (false)
    hostname: '83.150.217.40', // Lien pour accèder à la bdd
    port: 3306,
    user: 'bot_test', // Nom d'utilisateur bdd
    password: 'gJ6ss33jPiD5geC',  // Mot de passe bdd
    database: 'bot_test', // Nom de la table bdd
    
}
