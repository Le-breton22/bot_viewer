const { readdirSync } = require('fs'), { REST } = require('@discordjs/rest'), { Routes } = require('discord-api-types/v9');
const { clientId, token, guildId, slashCommandsByGuild } = require('./config.js');
const rest = new REST({ version: '9' }).setToken(token);
const commands = [];
readdirSync('./commands').forEach(dirs => {
    const commandFiles = readdirSync(`./commands/${dirs}/`).filter(files => files.endsWith(".js"));
    for (const file of commandFiles) { const command = require(`./commands/${dirs}/${file}`);
        commands.push(command.data.toJSON()); }
});
if (slashCommandsByGuild === true) {
    rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands }).then(() => console.log('Successfully registered guilds application commands.')).catch(console.error);
} else {
    rest.put(Routes.applicationCommands(clientId), { body: commands }).then(() => console.log('Successfully registered application commands.')).catch(console.error);
}