const { Client, Collection, GatewayIntentBits } = require('discord.js');
const config = require('./config.js');
const mysql = require('mysql')
const { loadCommands, loadButtons, loadSelectMenu, loadEvents } = require('./utils/loader');
const db = mysql.createConnection({ host: config.hostname, password: config.password, user: config.user, database: config.database });

const client = new Client({ intents: Object.values(GatewayIntentBits) });
["commands", "button", "selectMenu"].forEach(x => client[x] = new Collection());
loadCommands(client);
loadButtons(client);
loadSelectMenu(client);
loadEvents(client);

db.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
    db.query('SET NAMES utf8mb4');
});

client.db = db







client.on('interactionCreate', async(interaction) => {
    if (interaction.isCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;
        try {
            await command.execute(client, interaction);
        } catch (error) {
            console.error(error);
            try {
                await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
            } catch (error) { null };
        };
    } else if (interaction.isButton()) {
        const button = client.button.get(interaction.customId);
        try {
            await button.execute(client, interaction);
        } catch (error) {
            console.error(error);
            try {
                await interaction.reply({ content: 'There was an error while executing this button!', ephemeral: true });
            } catch (error) { null }
        }
    } else if (interaction.isStringSelectMenu()) {
        const selectMenu = client.selectMenu.get(interaction.customId);
        if (!selectMenu) return;
        try {
            await selectMenu.execute(client, interaction);
        } catch (error) {
            console.error(error);
            try {
                await interaction.reply({ content: 'There was an error while executing this select menu !', ephemeral: true });
            } catch (error) { null }
        }
    }
});
client.login(config.token);
