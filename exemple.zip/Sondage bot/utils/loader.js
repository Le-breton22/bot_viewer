const { readdirSync } = require("fs");

const loadCommands = async(client, dir = "./commands/") => {
    readdirSync(dir).forEach(dirs => {
        const commandFiles = readdirSync(`${dir}/${dirs}/`).filter(files => files.endsWith(".js"));
        for (const file of commandFiles) {
            const command = require(`../${dir}/${dirs}/${file}`);
            client.commands.set(command.data.name, command);
        };
    });
    const commands = [];
    await client.commands.map(x => commands.push({ commands: x.data.name }));
    console.table(commands);
};

const loadButtons = async(client, dir = "./interactions/buttons/") => {
    readdirSync(dir).forEach(dirs => {
        const buttonsFiles = readdirSync(`${dir}/${dirs}/`).filter(files => files.endsWith(".js"));
        for (const file of buttonsFiles) {
            const button = require(`../${dir}/${dirs}/${file}`);
            client.button.set(button.data.name, button);
        };
    });
    const button = [];
    await client.button.map(x => button.push({ button: x.data.name }));
    console.table(button);
};

const loadSelectMenu = async(client, dir = "./interactions/selectMenu/") => {
    readdirSync(dir).forEach(dirs => {
        const selectMenuFiles = readdirSync(`${dir}/${dirs}/`).filter(files => files.endsWith(".js"));
        for (const file of selectMenuFiles) {
            const selectMenu = require(`../${dir}/${dirs}/${file}`);
            client.selectMenu.set(selectMenu.data.name, selectMenu);
        };
    });
    const selectMenus = [];
    await client.selectMenu.map(x => selectMenus.push({ selectMenus: x.data.name }));
    console.table(selectMenus);
};
const loadEvents = (client, dir = "./events/") => {
    readdirSync(dir).forEach(dirs => {
        const events = readdirSync(`${dir}/${dirs}/`).filter(files => files.endsWith(".js"));

        for (const event of events) {
            const evt = require(`../${dir}/${dirs}/${event}`);
            const evtName = event.split(".")[0];
            client.on(evtName, evt.bind(null, client));
            console.log(`Evenement chargé : ${evtName}`)

        }
    })
}
module.exports = { loadCommands, loadButtons, loadSelectMenu, loadEvents };