module.exports = client => {
    console.log("Le bot est allumé")
    console.log(`Logged in as ${client.user.tag}!`);
    console.log(`${client.user.tag} observe les ${client.guilds.cache.map (g => g.memberCount).reduce((a, b) => a + b)} Utilisateurs du serveur !`);
    console.log("Chui près patron");
    console.log("Je te rend services");






// client.channels.cache.get('812350428200173588').send("Le bot est opérationnel!")

   
let activities = ['Menica', 'Site : menica.fr'];

setInterval(() => client.user.setPresence({ activities: [{ name: `${activities[Math.floor(Math.random() * activities.length)]}`, type: 'PLAYING'}, ]}), 3000); 

}