const { Collection, Guild } = require('discord.js'); 


module.exports = async (client, message) => {
    const guild = message.guild

  if (message.system) return

    if(message.channel.type === "dm") return;
    console.log(message.author.username + ' > ' + message.content);


    if(message.author.bot) return;


  



    if(!message.content.startsWith(prefix) || message.author.bot) return; 
    
 
    const args = message.content.slice(prefix.length).split(/ +/);
    
    const commandName = args.shift().toLowerCase();
    

    if(!client.commands.has(commandName)) return;
   
    const command = client.commands.get(commandName);

    command.run(client, message, args);
    
    // message.delete()
}
