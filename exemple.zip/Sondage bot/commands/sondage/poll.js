const { SlashCommandBuilder } = require('discord.js');
const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, PermissionsBitField, ChannelType, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
	data: new SlashCommandBuilder()
    .setName('create_poll')
    .setDescription('Création sondage')
    .addSubcommand(Option => Option.setName('titre').setDescription('titre').setRequired(true))
    .addSubcommand(Option => Option.setName('question').setDescription('Question à poser').setRequired(true)), 

    cmd: {
            category: 'sondage',
    },
	async execute(client, interaction) {

        const ok = new ButtonBuilder()
       
        .setCustomId("sondage_ok")
        .setLabel("OPTION")
        .setStyle(ButtonStyle.Primary)
        const nop = new ButtonBuilder()
       
        .setCustomId("sondage_nop")
        .setLabel("OPTION")
        .setStyle(ButtonStyle.Primary)
        const row = new ActionRowBuilder({ components: [ok, nop] });   

    const polltitre = interaction.options.getString('title');
    const PollContent = interaction.options.getString('question')
      if (!args[0]) return interaction.reply("Merci d'entrer une question pour le sondage ! ")
     

      var embed = new EmbedBuilder()
      .setTitle('📊', polltitre)
      .setDescription(PollContent)
      .setDescription('Oui' + interaction.options.getString(ok) + "\n\n\n" + 'Non' + interaction.options.getString(nop))
      .setColor('#F3AE1B')
  
      interaction.reply({embeds: [embed], components: [row]});      
    }
}