const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');

module.exports = {
    data: {
        name: 'poll_add'
    },
    async execute(client, interaction) {
      
if (interaction.customId === 'poll_add') {
   
   
      
    var embed = new EmbedBuilder()
    .setDescription(`Êtes-vous sur de vouloir supprimer le ticket définitivement ?`)
    .setColor('#F3AE1B')
interaction.reply({ embeds: [embed], components: [row] })
    
}

 
}

};