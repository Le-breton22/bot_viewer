const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');
  let hastebin = require('hastebin');

module.exports = {
    data: {
        name: 'ticket_Resolu'
    },
    async execute(client, interaction) {
        if (!interaction.channel.name.startsWith('ticket-'));

if (interaction.customId === 'ticket_Resolu') {
    let logsChannel = interaction.guild.channels.cache.find(c => c.id === "988058168124899401");

    var embed = new EmbedBuilder()
    .setTitle('Menica | System Ticket')
    .setDescription(`Suppresion ticket, raison : Resolu`)
    .setColor('#F3AE1B')
    .setFooter({ text: 'System Ticket | Fermeture'});

    logsChannel.send({embeds: [embed]});      

    if(interaction.channel.name.startsWith(`ticket-`) || interaction.channel.name === ticketName) {
        let file = await Transcript.createTranscript(interaction.channel, {
          limit: -1,
          returnType: 'attachment',
          filename: `TicketTranscript-${interaction.channel.name}.html`,
          saveImages: false,
          footerText: `Exported {number} message{s}.`,
          poweredBy: false
        })
        await interaction.reply({
          embeds: [new EmbedBuilder().setColor("#0xF3AE1B").setDescription(`Creating transcript of ${interaction.channel} for you and this will send you from dm so please wait.`).setTitle(`Transcript| Build Transcript For You`)],
          ephemeral: true
        })
        await logsChannel.send({
         files: [file],
         embeds: [new EmbedBuilder().setColor("#0xF3AE1B").setDescription(`Creating the \`${interaction.channel.name}\` ticket of ${interaction.guild.name} transcript have successfull, Raison fermeture : Resolu `).setTitle(`| Successfully Transcript Created`).setAuthor({ name: `${interaction.channel.name} • ${interaction.guild.name}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })],
      })
        await interaction.user.send({
          files: [file],
          embeds: [new EmbedBuilder().setColor("#0xF3AE1B").setDescription(`Creating the \`${interaction.channel.name}\` ticket of ${interaction.guild.name} transcript have successfull.`).setTitle(`| Successfully Transcript Created`).setAuthor({ name: `${interaction.channel.name} • ${interaction.guild.name}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })],
        })
       }else{
          errorMessage(client, interaction, `**My Friend, here is not a ticket channel please use this command in other channel**`)
       }
     
      
     
         
               logsChannel.send({embeds: [embed]});                


    interaction.channel.delete()
    
}

 
}

};