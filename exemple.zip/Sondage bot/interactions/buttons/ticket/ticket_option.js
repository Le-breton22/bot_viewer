const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, PermissionsBitField, ChannelType, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    data: {
        name: 'ticket_option'
    },
    async execute(client, interaction) {
        if (!interaction.channel.name.startsWith('ticket-'));

if (interaction.customId === 'ticket_option') {

    const menu = new StringSelectMenuBuilder()
    .setCustomId("ticket_option_bis")
    .setMaxValues(1)
    .addOptions([
        { label: "Ajouter Membre", description: "Ajout membre au  Ticket", value: "ticket_add" },
        { label: "Enlever Membre", description: "Enlever membre au  Ticket", value: "ticket_remove" },

    ]);
    const row = new ActionRowBuilder({ components: [menu] });

    var emticket = new EmbedBuilder()
    .setTitle(`Bienvenue sur le système d'option des tickets`)
    .setDescription(`Veulliez selectionner l'option`)
    .setColor("#0xF3AE1B")
    .setTimestamp()
    let msg = await interaction.reply({embeds: [emticket], components: [row] });




}

 
}

};