const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events, ActionRow } = require('discord.js');
module.exports = {
    data: {
        name: 'ticket_close'
    },
    async execute(client, interaction) {
        if (!interaction.channel.name.startsWith('ticket-'));

if (interaction.customId === 'ticket_close') {


    const option2 = new ButtonBuilder()
       
    .setCustomId('ticket_Resolu')
        .setLabel('Resolu')
        .setStyle(ButtonStyle.Danger)


        const option3 = new ButtonBuilder()
       
        .setCustomId('ticket_abandon')
            .setLabel('Abandon')
            .setStyle(ButtonStyle.Primary)

  

    const row = new ActionRowBuilder({ components: [option2, option3] });   
    
    var embed = new EmbedBuilder()
    .setDescription(`Êtes-vous sur de vouloir supprimer le ticket définitivement ?`)
    .setColor('#F3AE1B')
interaction.reply({ embeds: [embed], components: [row] })
}

 
}

}; 