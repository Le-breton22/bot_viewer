const { ChannelType, StringSelectMenuBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, SlashCommandBuilder } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, AudioPlayer } = require('@discordjs/voice');
const { arbitraryStream } = require("discord-ytdl-core");
const voiceDiscord = require(`@discordjs/voice`)

module.exports = {
    data: {
        name: 'radio_choice'
    },
    async execute(client, interaction) {
        if(!interaction.member.voice.channel) return interaction.reply({ embeds: [new EmbedBuilder().setDescription("Vous devez être connecté à un salon vocal pour utiliser ce menu.").setColor("#0xRED")] });
        
        const menu = new StringSelectMenuBuilder()
        .setCustomId("radio_choice")
        .setMaxValues(1)
        .addOptions([
            { label: "Skyrock", description: "Skyrock", value: "radio_1", emoji: "<:Skyrock:993561752535056484>" },
            { label: "France Bleu", description: "France Bleu", value: "radio_2", emoji: "<:FranceBleu:993561739524325386>" },
            { label: "Fun Radio France", description: "Fun Radio France", value: "radio_3", emoji: "<:FUNRadio:993548196297060352>"  },
            { label: "NRJ", description: "NRJ", value: "radio_4", emoji: "<:NRJ:993561747392843927>"  },
            { label: "RFM", description: "RFM", value: "radio_5", emoji: "<:RFM:993561749070561411>"  },
            { label: "Top Music Mulhouse", description: "Top Music Mulhouse", value: "radio_6", emoji: "<:TopMusic:993561754313424936>"  }
        ]);
        const row2 = new ActionRowBuilder({ components: [menu] });
        const m = interaction.message;

        
        
        
        const radio = interaction.values[0];
        const RadioLinks = {
            radio_1: "http://icecast.skyrock.net/s/natio_mp3_128k",
            radio_2: "http://icecast.radiofrance.fr/franceinfo-hifi.aac",
            radio_3: "http://icecast.funradio.fr/fun-1-44-128?listen=webCwsBCggNCQgLDQUGBAcGBg",
            radio_4: "http://scdn.nrjaudio.fm/adwz2/fr/30001/mp3_128.mp3?origine=fluxradios",
            radio_5: "https://ais-live.cloud-services.paris:8443/rfm.mp3",
            radio_6: "http://str0.creacast.com/topmusic_mulhouse"
        };

        const connection = voiceDiscord.joinVoiceChannel({
            channelId: interaction?.member?.voice?.channel.id,
            guildId: interaction.guild.id,
            adapterCreator: interaction.guild.voiceAdapterCreator,
            selfDeaf: true,
        });
        const player = voiceDiscord.createAudioPlayer();
        const resource = voiceDiscord.createAudioResource(RadioLinks[radio]);
        player.play(resource);
        connection.subscribe(player);




        switch(radio) {
            case "radio_1": {
                const embed = new EmbedBuilder()
                .setTitle("skyrock")
                .setDescription("**Connexion effectuée avec succès !**")
                .setColor('#0x008000')
                .setURL("https://www.skyrock.com/")
                .setThumbnail("https://upload.wikimedia.org/wikipedia/fr/thumb/b/b7/SKYROCK_FM_LOGO.svg/1200px-SKYROCK_FM_LOGO.svg.png")
                .setTimestamp();
                interaction.reply({ embeds: [embed] }) 
                setTimeout(()=>{
                    interaction.deleteReply();
                }, 10000);
                m.edit({
                    components: [row2]                     // Selection  Radio
                })
                break;
            }
            case "radio_2": {
                const embed2 = new EmbedBuilder()
                .setTitle("FranceInfo")
                .setDescription("**Connexion effectuée avec succès !**")
                .setColor('#0x008000')
                .setURL("https://www.francetvinfo.fr/en-direct/radio.html")
                .setThumbnail("https://www.france.tv/images/logos/social/franceinfo.jpg")
                .setTimestamp();
                interaction.reply({ embeds: [embed2] })
                setTimeout(()=>{
                    interaction.deleteReply();
                }, 10000);
                m.edit({
                    components: [row2]                     // Selection  Radio
                })
                break;
            }
            case "radio_3": {
                const embed3 = new EmbedBuilder()
                .setTitle("Fun Radio")
                .setDescription("**Connexion effectuée avec succès !**")
                .setDescription("Bonne écoute avec Fun Radio")
                .setColor('#0x008000')
                .setURL("https://www.funradio.fr/")
                .setThumbnail("https://upload.wikimedia.org/wikipedia/fr/thumb/e/eb/Fun_Radio.png/800px-Fun_Radio.png")
                .setTimestamp();
                interaction.reply({ embeds: [embed3] })
                setTimeout(()=>{
                    interaction.deleteReply();
                }, 10000);
                m.edit({
                    components: [row2]                     // Selection  Radio
                })                
                break;
            }
            case "radio_4": {
                const embed4 = new EmbedBuilder()
                .setTitle("NRJ")
                .setDescription("**Connexion effectuée avec succès !**")
                .setColor('#0x008000')
                .setURL("https://www.nrj.fr/")
                .setThumbnail("https://img.nrj.fr/Tpoy4-6dIL3YQCEn0cf2-qBuwFg=/https%3A%2F%2Fplayers.nrjaudio.fm%2Flive-metadata%2Fplayer%2Fimg%2Fplayer-files%2Fnrj%2Flogos%2F640x640%2FP_NRJ_V3.png")
                .setTimestamp();
                interaction.reply({ embeds: [embed4] })
                setTimeout(()=>{
                    interaction.deleteReply();
                }, 10000);
                m.edit({
                    components: [row2]                     // Selection  Radio
                })
                break;
            }
            case "radio_5": {
                const embed4 = new EmbedBuilder()
                .setTitle("RFM")
                .setDescription("**Connexion effectuée avec succès !**")
                .setColor('#0x008000')
                .setURL("http://www.rfm.fr/")
                .setThumbnail("https://upload.wikimedia.org/wikipedia/fr/thumb/1/19/RFM_logo_2011.png/195px-RFM_logo_2011.png")
                .setTimestamp();
                interaction.reply({ embeds: [embed4] })
                setTimeout(()=>{
                    interaction.deleteReply();
                }, 10000);
                m.edit({
                    components: [row2]                     // Selection  Radio
                })
                break;
            }
            case "radio_6": {
                const embed4 = new EmbedBuilder()
                .setTitle("Top Music Mulhouse ")
                .setDescription("**Connexion effectuée avec succès !**")
                .setColor('#0x008000')
                .setURL("https://www.topmusic.fr//")
                .setThumbnail("https://images.lesindesradios.fr/filters:quality(100)/radios/top-music/images/logo.png")
                .setTimestamp();
                interaction.reply({ embeds: [embed4] })
                setTimeout(()=>{
                    interaction.deleteReply();
                }, 10000);
                m.edit({
                    components: [row2]                     // Selection  Radio
                })
                break;
            }
        };
    },
};