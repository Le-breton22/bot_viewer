const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, PermissionsBitField, ChannelType, ButtonBuilder, ButtonStyle } = require("discord.js");
module.exports = {
    data: {
        name: 'ticket_create'
    },
    async execute(client, interaction, message, guild, user) {

        const ticket = interaction.values[0];


        let split = '';
        let usr = interaction.user.id.split(split);
        for (var i = 0; i < usr.length; i++) usr[i] = usr[i].trim();
        const m = interaction.message;

        client.db.query("select * from ticketconfig", async function(err, results) {
            if (err) throw err;
            const guild = JSON.parse(`${(results[0].TicketCategory).toString()}`)
            const newArray = guild.filter(option => option.value == interaction.values[0])
            let logsChannel = interaction.guild.channels.cache.find(c => c.id === newArray[0].logs);

            let already = new EmbedBuilder()
                .setColor("Red")
                .setThumbnail(`${newArray[0].thumbnail}`)
                .setTitle(`:lock: | Interdit`)
                .setDescription(`Vous ne pouvez avoir qu'un seul ticket d'ouvert à la fois.`);

            let success = new EmbedBuilder()
                .setColor("#F3AE1B")
                .setThumbnail(`${newArray[0].thumbnail}`)
                .setTitle(`${newArray[0].embed_title}`)
                .setDescription(`${newArray[0].embed_description}`);


            // Dmemande Info 
            
            let info = new EmbedBuilder()
                .setColor("#F3AE1B")
                .setThumbnail(`${newArray[0].thumbnail}`)
                .setTitle(`Info Personnel`)
                .setDescription(`Bonjour et bienvnue Chez Menica, pour mieux traiter votre demande veuliez s.v.p  nous donnez les info suivantes \n nom : \n prénom:`);


            //  Message Edit
            const menu = new StringSelectMenuBuilder()
                .setCustomId("ticket_create")
                .setMaxValues(1)
                .setPlaceholder('Sélectionnez la catégorie de ticket ci-dessous correspondant à votre demande.')
                .addOptions(guild)
            const row2 = new ActionRowBuilder({ components: [menu] });


            if (ticket) {
                if (interaction.guild.channels.cache.some(c => c.name == `ticket-${interaction.user.id}`)) {
                    await interaction.reply({ embeds: [already] });
                    setTimeout(async() => {
                        await interaction.deleteReply();
                    }, 10000); // Interdiction d'un 2nd ticket
                    m.edit({ components: [row2] }) // Selection  ticket
                } else {
                    let permsToHave = [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.EmbedLinks, PermissionsBitField.Flags.AttachFiles, PermissionsBitField.Flags.ReadMessageHistory, PermissionsBitField.Flags.ManageRoles]

                    await interaction.guild.channels.create({ name: `ticket-${interaction.user.id}`, type: ChannelType.GuildText, parent: newArray[0].category == null ? null : newArray[0].category }).then(async channel_ticket => {
                        const role = interaction.guild.roles.cache.get(newArray[0].role);
                        if (role) {
                            await channel_ticket.permissionOverwrites.set([{ id: interaction.guild.id, deny: PermissionsBitField.Flags.ViewChannel }, { allow: permsToHave, id: interaction.user.id }, { id: role.id, allow: permsToHave }])
                        } else {
                            await channel_ticket.permissionOverwrites.set([{ id: interaction.guild.id, deny: PermissionsBitField.Flags.ViewChannel }, { allow: permsToHave, id: interaction.user.id }])
                        }
                        var ticketok = new EmbedBuilder()
                            .setAuthor({ name: `Votre ticket a été crée avec succès - ${interaction.user.username}` })
                            .setColor("Random")
                            .setDescription(`Votre ticket : ${channel_ticket}`)
                            .setFooter({ text: '\n\n© Menica | Un membre du personnel viendra vers vous dans quelques instant.' })
                            .setTimestamp()
                        await interaction.reply({ embeds: [ticketok], ephemeral: true })


                        const option2 = new ButtonBuilder()
       
                        .setCustomId("ticket_close")
                        .setLabel("Fermeture")
                        .setStyle(ButtonStyle.Danger)

                        const option3 = new ButtonBuilder()
       
                        .setCustomId("ticket_option")
                        .setLabel("OPTION")
                        .setStyle(ButtonStyle.Primary)
                        const row = new ActionRowBuilder({ components: [option2, option3] });
        

                        channel_ticket.send({ embeds: [success, info], components: [row] });
                        m.edit({ components: [row2] })

                        let createdEmbed = new EmbedBuilder()
                            .setTitle(`${newArray[0].emoji} | Ticket Ouvert`)
                            .setTimestamp()
                            .setColor("#F3AE1B")
                            .setThumbnail(`${newArray[0].thumbnail}`)
                            .setFooter({ text: `Système de Ticket`, iconURL: interaction.client.user.displayAvatarURL() })
                            .setDescription(`Un utilisateur à ouvert un ticket (${ticket}).`)
                            .addFields({ name: `Informations`, value: `**Utilisateur :** \`${interaction.user.tag}\`\n**ID :** \`${interaction.user.id}\`\n**Ticket :** ${channel_ticket}\n` })
                        logsChannel ? logsChannel.send({ embeds: [createdEmbed] }) : null;
                    })
                }
            }
        })
    }
}